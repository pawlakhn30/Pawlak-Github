let height;
function setup() {
  createCanvas(400, 400);
  height = 335;
}

function draw() {
  background(220);
  tree();
  acorn();
}

function tree() {
  push();
  for (let num = 0; num < 3; num++){
  translate(100,0);
    fill(100, 100, 0)
  rect(0, 200, 30, 200);
  leaves();
  }

  pop();
}

function leaves() {
  for (let i = 0; i<150; i+=50){
    fill(0, 255, 0);
    beginShape();
    vertex(15,i+150);
    vertex(70, i+230);
    vertex(-40, i+230);
    vertex(15,i+150);
    endShape();
  }
}

function acorn(){
  fill(125, 60, 10);
  let array = []; 
  for (let i = 0; i < 3; i++){
    array[i] = i*100+100;
  ellipse(array[i], height, 10, 15);
    print(array[i]);
  }
  height++;
  if (height == 400)
    height = 335;
}