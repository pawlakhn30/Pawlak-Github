let disposal;
let garbage;

function preload() {
	disposal = loadImage('amongus.png');
	garbage = loadImage('trash.png');
}

function setup() {
	createCanvas(400, 400);

background(50);
}

function draw() {
	let mx = mouseX;
	let my = mouseY;

	image(disposal, 0, 0, 400, 400);
	image(garbage, mx-75 , my-75, 150, 150);
	
	textSize(50);
	text('weeeee', mx, my-75);
	textSize(20);
	textFont('pacifico');
	stroke(255);
	text('wubbba lubba dub dub', 35, 50);
	stroke(0);
}